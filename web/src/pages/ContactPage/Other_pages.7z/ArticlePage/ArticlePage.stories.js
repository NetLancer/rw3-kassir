import ArticlePage from './ArticlePage'

export const generated = () => {
  return <ArticlePage id={1} />
}

export default { title: 'Pages/ArticlePage' }
