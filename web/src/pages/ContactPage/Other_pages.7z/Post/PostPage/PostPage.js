import PostCell from 'src/components/Post/PostCell'

const PostPage = ({ id }) => {
  return <PostCell id={id} />
}

export default PostPage
