import EditPostCell from 'src/components/Post/EditPostCell'

const EditPostPage = ({ id }) => {
  return <EditPostCell id={id} />
}

export default EditPostPage
