// Define your own mock data here:
export const standard = () => ({
  comments: [{ id: 42 }, { id: 43 }, { id: 44 }],
})
