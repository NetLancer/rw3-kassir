import { Link, routes } from '@redwoodjs/router' 
import CommentsCell from 'src/components/CommentsCell'
import CommentForm from 'src/components/CommentForm'

const truncate = (text,length) => (text.substring(0, length) + '...')

//////////////////////////////
/////////////
const Article = ({ article, summary = false }) => { 
  //
  return (
    <article className="mt-10">
      <header>
        <h2 className="text-xl text-blue-700 font-semibold">
          <Link to={routes.article({ id: article.id })}>{article.title}</Link>
        </h2>
      </header>
      <div className="mt-2 text-gray-900 font-light">
      {summary ? truncate(article.body, 80) : article.body}
      </div> 
      {!summary && (
        <>
          <CommentForm postId={article.id} />
          <CommentsCell postId={article.id} /> 
        </>
      )}
    </article>
  )
}

export default Article
